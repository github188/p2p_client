#ifndef __TM_H__
#define __TM_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

int64_t now_ms_time();

#ifdef __cplusplus
}
#endif

#endif