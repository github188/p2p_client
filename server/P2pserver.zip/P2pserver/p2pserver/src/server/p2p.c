#define P2P_VERSION "1.0.0.0"

//xzl--往客户端发送命令
static void send_p2p_request_to_client(ts_ur_super_session *ss, int msg_type)
{
	turn_turnserver *server=(turn_turnserver*)(ss->server);
	if(!server)
		return;
	//xzl--获取该客户端一个可用的buffer。该buffer可以循环使用，一个客户端可以有最多64个buffer
	ioa_network_buffer_handle nbh = ioa_network_buffer_allocate(server->e);
	//xzl--stun_init_request_str函数最后一个参数是出参，而不是入参，所以不需要赋值
	size_t len; //= ioa_network_buffer_get_size(nbh);
	//xzl--我们的最定义P2P命令都是0x1000以上的。stun_init_request_str函数内部会生成tid
	stun_init_request_str(msg_type | 0x1000 ,ioa_network_buffer_data(nbh), &len);
	//xzl--设置数据长度，其实这个数据长度都是固定20个字节的，也就是STUN消息头固定长度
	ioa_network_buffer_set_size(nbh,len);
	//xzl--写入数据
	write_client_connection(server, ss, nbh, TTL_IGNORE, TOS_IGNORE);
}
//xzl--往客户端发送成功回复。每次回复都要跟请求的tid相同
static void send_p2p_response_to_client(ts_ur_super_session *ss, int msg_type, stun_tid* tid)
{
	turn_turnserver *server=(turn_turnserver*)(ss->server);
	if(!server)
		return;
	//xzl--获取该客户端一个可用的buffer。该buffer可以循环使用，一个客户端可以有最多64个buffer
	ioa_network_buffer_handle nbh = ioa_network_buffer_allocate(server->e);
	//xzl--stun_init_success_response_str函数最后一个参数是出参，而不是入参，所以不需要赋值
	size_t len ;//= ioa_network_buffer_get_size(nbh);
	//xzl--我们的最定义P2P回复都是0x1100以上的
	stun_init_success_response_str(msg_type | 0x1100, ioa_network_buffer_data(nbh), &len, tid);
	//xzl--设置数据长度。其实这个数据长度都是固定20个字节的，也就是STUN消息头固定长度
	ioa_network_buffer_set_size(nbh,len);
	//xzl--写入数据
	write_client_connection(server, ss, nbh, TTL_IGNORE, TOS_IGNORE);
}

static void delete_p2p_session_from_map(ts_ur_super_session* ss)
{
	ts_ur_super_session *remote_ss = 0;
	int ret = 0;
	if(ss->is_p2p_assist)
	{   //xzl--该客户端是assist类型
		if(ss->username[0] && ss->kickout == 0)
		{   //该客户端是有效客户端并且还没被踢出，这时我们进行提出操作
			ur_string_map_del( p2p_server.p2p_assist_connections, (ur_string_map_key_type)ss->username);
			async_db_client_shutdown((char*)ss->username);
		}
	}
	else
	{   //xzl--该客户端是assist类型,而是initiative或passivity类型
		if(ss->session_id[0])
		{   //xzl--判读该客户端是否为有效客户端。有效客户端才会记录在map中
			if(ss->is_initiative)
			{   //xzl--这是个initiative客户端，从p2p_initiative_connections map中删除之
				ur_string_map_del(p2p_server.p2p_initiative_connections, (ur_string_map_key_type)ss->session_id);
                //xzl--找到对应的passivity客户端，然后我们通知它掉线
				ret = ur_string_map_get(p2p_server.p2p_passivity_connections, 
					(ur_string_map_key_type)ss->session_id,	
					(ur_string_map_value_type*)&remote_ss);
				if(ret && remote_ss) //notify and close passivity connection
				{
                    //xzl--发送P2P_DISCONNNECT_REQUEST命令通知其掉线
					send_p2p_request_to_client(remote_ss, STUN_METHOD_P2P_DISCONNNECT_REQUEST);
                    //xzl--标记它下次Refresh命令时服务器主动踢出
					remote_ss->kickout = 1;
				}
			}
			else
			{
                //xzl--这是个p2p_passivity客户端，p2p_passivity_connections map中删除之
				ur_string_map_del(p2p_server.p2p_passivity_connections, (ur_string_map_key_type)ss->session_id);

                //xzl--找到对应的initiative客户端，然后我们通知它掉线
				ret = ur_string_map_get(p2p_server.p2p_initiative_connections, 
					(ur_string_map_key_type)ss->session_id,	
					(ur_string_map_value_type*)&remote_ss);
				if(ret && remote_ss) //notify and close initiative connection
				{
                    //xzl--发送P2P_DISCONNNECT_REQUEST命令通知其掉线
					send_p2p_request_to_client(remote_ss, STUN_METHOD_P2P_DISCONNNECT_REQUEST);
                    //xzl--标记它下次Refresh命令时服务器主动踢出
                    remote_ss->kickout = 1;
				}
			}
		}
	}
}

//xzl--我们的扩展命令都是0x1000以上的
static int is_p2p_msg_type(u16bits type)
{
	return ((type & 0xF000)==0x1000);
}

static int forward_write_client_connection(turn_turnserver *server, ts_ur_super_session* ss, ioa_net_data *in_buffer) 
{
	int ret;
	//xzl--把收到的数据完全转发到客户端
	ret = write_client_connection(server, ss, in_buffer->nbh, TTL_IGNORE, TOS_IGNORE);
	//xzl--表明收到的数据已经被消费，上层调用请勿回收或释放之
	in_buffer->nbh = NULL;
	return ret;
}

//xzl--统计客户端汇报的数据流量
static void add_conn_transmit_count(ur_string_map_value_type value)
{
	ts_ur_super_session* ss = value;
	p2p_server.total_transmit_count += ss->refresh_transmit_count;
}
//xzl--统计客户端汇报的数据流量
static void client_report_transmit_count(ts_ur_super_session *ss, int msg_type, stun_tid* tid, int transmit_count)
{
	ss->refresh_transmit_count = transmit_count;
	turn_turnserver *server=(turn_turnserver*)(ss->server);
	if(!server)
		return;

	turn_mutex_lock(&p2p_server.p2p_mutex);
	p2p_server.total_transmit_count = 0;
	ur_string_map_foreach(p2p_server.p2p_assist_connections, add_conn_transmit_count);
	transmit_count = p2p_server.total_transmit_count/ ur_string_map_size(p2p_server.p2p_assist_connections);
	p2p_server.avg_transmit_count = transmit_count;
	turn_mutex_unlock(&p2p_server.p2p_mutex);
					
	ioa_network_buffer_handle nbh = ioa_network_buffer_allocate(server->e);
	size_t len = ioa_network_buffer_get_size(nbh);
	u16bits* method;
	stun_init_success_response_str(msg_type, ioa_network_buffer_data(nbh), &len, tid);
	method = (u16bits*)ioa_network_buffer_data(nbh);
	*method |= nswap16(0x1100); //p2p response message 

	transmit_count = nswap32(transmit_count);
	stun_attr_add_str(ioa_network_buffer_data(nbh), &len, STUN_ATTRIBUTE_P2P_TRANSMIT_COUNT, (const u08bits*)&transmit_count, sizeof(transmit_count));
	ioa_network_buffer_set_size(nbh, len);
											
	write_client_connection(server, ss, nbh, TTL_IGNORE, TOS_IGNORE);
}
//xzl--处理客户端汇报命令
static void p2p_report_session_info(ts_ur_super_session *ss, ioa_net_data *in_buffer, int *resp_constructed, stun_tid* tid)
{
	u08bits remote_user[STUN_MAX_USERNAME_SIZE]={0};
	u08bits remote_addr[128]={0};
	u08bits local_addr[128]={0};
	u08bits guid[128]={0};
	size_t len;
	int conn_id = 0;
	int type = 0;
	int connect_time = 0;
	int connect_result = 0;
	int transmit_count = -1;
	
	*resp_constructed = 0;
	stun_attr_ref sar = stun_attr_get_first_str(ioa_network_buffer_data(in_buffer->nbh),
				ioa_network_buffer_get_size(in_buffer->nbh));

	while (sar) 
	{
		int attr_type = stun_attr_get_type(sar);
		switch(attr_type)
		{
		case STUN_ATTRIBUTE_P2P_TRANSMIT_COUNT:
			if (stun_attr_get_len(sar) == 4) {
				const u08bits* value = stun_attr_get_value(sar);
				if(value)
					transmit_count = nswap32(*((const u32bits*)value));
			}
			break;
			
		case STUN_ATTRIBUTE_P2P_REMOTE_USER:
			len = min((size_t)stun_attr_get_len(sar), sizeof(remote_user)-1);
			ns_bcopy(stun_attr_get_value(sar), remote_user, len);
			remote_user[len]=0;
			break;
		case STUN_ATTRIBUTE_P2P_CONN_ID:
			if (stun_attr_get_len(sar) == 4) {
				const u08bits* value = stun_attr_get_value(sar);
				if(value)
					conn_id = nswap32(*((const u32bits*)value));
			}
			break;
		case STUN_ATTRIBUTE_P2P_LOCAL_INFO:
			len = min((size_t)stun_attr_get_len(sar), sizeof(local_addr)-1);
			ns_bcopy(stun_attr_get_value(sar), local_addr, len);
			local_addr[len]=0;
			break;
		case STUN_ATTRIBUTE_P2P_REMOTE_INFO:
			len = min((size_t)stun_attr_get_len(sar), sizeof(remote_addr)-1);
			ns_bcopy(stun_attr_get_value(sar), remote_addr, len);
			remote_addr[len]=0;
			break;
		case STUN_ATTRIBUTE_P2P_TYPE:
			if (stun_attr_get_len(sar) == 4) {
				const u08bits* value = stun_attr_get_value(sar);
				if(value)
					type = nswap32(*((const u32bits*)value));
			}
			break;
		case STUN_ATTRIBUTE_P2P_GUID:
			len = min((size_t)stun_attr_get_len(sar), sizeof(guid)-1);
			ns_bcopy(stun_attr_get_value(sar), guid, len);
			guid[len]=0;
			break;
		case STUN_ATTRIBUTE_P2P_CONN_TIME:
			if (stun_attr_get_len(sar) == 4) {
				const u08bits* value = stun_attr_get_value(sar);
				if(value)
					connect_time = nswap32(*((const u32bits*)value));
			}
			break;
		case STUN_ATTRIBUTE_P2P_CONN_RESULT:
			if (stun_attr_get_len(sar) == 4) {
				const u08bits* value = stun_attr_get_value(sar);
				if(value)
					connect_result = nswap32(*((const u32bits*)value));
			}
			break;
		}
		sar = stun_attr_get_next_str(ioa_network_buffer_data(in_buffer->nbh),
					ioa_network_buffer_get_size(in_buffer->nbh),
					sar);
	}

	if(transmit_count != -1)
	{
		client_report_transmit_count(ss, STUN_METHOD_P2P_REPORT_SESSION_INFO, tid, transmit_count);
		return;
	}
	
	if(connect_result == -1) // connect_result is -1, the session is destroyed
		async_db_report_session_destroy((const char*)guid,conn_id);
	else
		async_db_report_session_info((const char*)remote_user,
		(const char*)remote_addr,
		(const char*)local_addr,
		(const char*)guid,
		conn_id,
		type,
		connect_time,
		connect_result);
	send_p2p_response_to_client(ss, STUN_METHOD_P2P_REPORT_SESSION_INFO, tid);
}

//xzl--处理自定义命令
static int handle_p2p_turn_command(turn_turnserver *server, //relay服务器
								   ts_ur_super_session *ss, //客户端会话信息
								   ioa_net_data *in_buffer, //收到的数据
								   ioa_network_buffer_handle nbh, //用于存放响应数据
								   int *resp_constructed, //是否已经存放响应数据，如果是，上层调用帮你发送
								   u16bits msg_type, //命令类型
								   stun_tid* tid)//请求或回复tid
{
	UNUSED_ARG(nbh);
	switch(msg_type)
	{
	case STUN_METHOD_P2P_REPORT_SESSION_INFO:
		p2p_report_session_info(ss, in_buffer, resp_constructed, tid);
		break;
		
	case STUN_METHOD_P2P_CONNNECT_REQUEST:
	case STUN_METHOD_P2P_CONNNECT_RESPONSE:
	case STUN_METHOD_P2P_CONNNECT_ERROR_RESPONSE:
		{	//xzl--连接请求命令相关，完全转发
			*resp_constructed = 0;
			stun_attr_ref sar = stun_attr_get_first_str(ioa_network_buffer_data(in_buffer->nbh),
				ioa_network_buffer_get_size(in_buffer->nbh));

			while (sar) 
			{
				int attr_type = stun_attr_get_type(sar);
				if(attr_type == STUN_ATTRIBUTE_P2P_REMOTE_USER)
				{	//xzl--提取对端用户名
					u08bits user[STUN_MAX_USERNAME_SIZE];
					size_t len;
					ts_ur_super_session *remote_ss;
					len = min((size_t)stun_attr_get_len(sar), sizeof(user)-1);
					ns_bcopy(stun_attr_get_value(sar), user, len);
					user[len]=0;

					//xzl--由于是不同客户端间的操作，可能存在跨relay服务器的情况，所以我们要对数据上锁
					turn_mutex_lock(&p2p_server.p2p_mutex);
					//xzl--转发数据给对端。发起连接请求和回复只会是assist类型的客户端发出
					if(ur_string_map_get(p2p_server.p2p_assist_connections, (ur_string_map_key_type)user, (ur_string_map_value_type*)&remote_ss))
						forward_write_client_connection(server, remote_ss, in_buffer);
					turn_mutex_unlock(&p2p_server.p2p_mutex);
					break;
				}
				sar = stun_attr_get_next_str(ioa_network_buffer_data(in_buffer->nbh),
					ioa_network_buffer_get_size(in_buffer->nbh),
					sar);
			}
		}
		break;
	case STUN_METHOD_P2P_EXCHANGE_INFO_REQUEST:
		{
			*resp_constructed = 0;
			ts_ur_super_session *remote_ss;
			//xzl--由于是不同客户端间的操作，可能存在跨relay服务器的情况，所以我们要对数据上锁
			turn_mutex_lock(&p2p_server.p2p_mutex);
			//xzl--交换IP请求只可能是initiative发出的，所以他的对端一定是passivity类型
			if(ur_string_map_get(p2p_server.p2p_passivity_connections,
				(ur_string_map_key_type)ss->session_id,
				(ur_string_map_value_type*)&remote_ss))
				//xzl--完全转发数据
				forward_write_client_connection(server, remote_ss, in_buffer);
			turn_mutex_unlock(&p2p_server.p2p_mutex);
		}
		break;
	case STUN_METHOD_P2P_EXCHANGE_INFO_RESPONSE:
	case STUN_METHOD_P2P_EXCHANGE_INFO_ERROR_RESPONSE:
		{
			*resp_constructed = 0;
			ts_ur_super_session *remote_ss;
			//xzl--由于是不同客户端间的操作，可能存在跨relay服务器的情况，所以我们要对数据上锁
			turn_mutex_lock(&p2p_server.p2p_mutex);
			//xzl--交换IP回复只可能是passivity发出的，所以他的对端一定initiative类型
			if(ur_string_map_get(p2p_server.p2p_initiative_connections,
				(ur_string_map_key_type)ss->session_id, 
				(ur_string_map_value_type*)&remote_ss))
				//xzl--完全转发数据
				forward_write_client_connection(server, remote_ss, in_buffer);
			turn_mutex_unlock(&p2p_server.p2p_mutex);
		}
		break;
	case STUN_METHOD_P2P_CLOSE_RELAYED_SOCKET:
		{
			*resp_constructed = 0;
			ts_ur_super_session *remote_ss;
			turn_mutex_lock(&p2p_server.p2p_mutex);
			if(ss->is_initiative)
			{	//xzl--如果是initiative类型发出该请求，那说明initiative至passivity的链路已经打通，passivity无需再为initiative准备中继端口
				if(ur_string_map_get(p2p_server.p2p_passivity_connections, 
				(ur_string_map_key_type)ss->session_id,
				(ur_string_map_value_type*)&remote_ss))
				{
					if(remote_ss->alloc.relay_session.s != p2p_server.p2p_assist_relay_socket)
					{	//xzl--如果不是全局中继端口，我们会关闭这个真实的中继端口，然后赋值给它一个假的全局的中继端口
						IOA_CLOSE_SOCKET(remote_ss->alloc.relay_session.s);
						remote_ss->alloc.relay_session.s = p2p_server.p2p_assist_relay_socket;
					}
				}
			}
			else
			{	//xzl--如果是passivity类型发出该请求，那说明passivity至initiative的链路已经打通，initiative无需再为passivity准备中继端口
				if(ur_string_map_get(p2p_server.p2p_initiative_connections,
					(ur_string_map_key_type)ss->session_id, 
					(ur_string_map_value_type*)&remote_ss))
				{
					if(remote_ss->alloc.relay_session.s != p2p_server.p2p_assist_relay_socket)
					{
						//xzl--如果不是全局中继端口，我们会关闭这个真实的中继端口，然后赋值给它一个假的全局的中继端口
						IOA_CLOSE_SOCKET(remote_ss->alloc.relay_session.s);
						remote_ss->alloc.relay_session.s = p2p_server.p2p_assist_relay_socket;
					}
				}
			}
			turn_mutex_unlock(&p2p_server.p2p_mutex);
			//xzl--发送成功回复
			send_p2p_response_to_client(ss, STUN_METHOD_P2P_CLOSE_RELAYED_SOCKET, tid);
		}
		break;
	default:
		*resp_constructed = 0;
		break;
	}
	return 0;
}

extern void init_user_pwd_map(void);
//xzl--初始化全局map表、异步sql、负载均衡客户端
void init_p2p_server(void)
{
	TURN_LOG_FUNC(TURN_LOG_LEVEL_INFO, "******p2p version %s******\n", P2P_VERSION);

	turn_mutex_init_recursive(&p2p_server.p2p_mutex);
	p2p_server.p2p_assist_relay_socket = 0;
	p2p_server.p2p_assist_connections = ur_string_map_create(0);
	p2p_server.p2p_initiative_connections = ur_string_map_create(0);
	p2p_server.p2p_passivity_connections = ur_string_map_create(0);
	p2p_server.total_transmit_count = 1;
	p2p_server.avg_transmit_count = 1;
	p2p_report_init();

	TURN_LOG_FUNC(TURN_LOG_LEVEL_INFO, "init user password map begin\n");
	init_user_pwd_map();
	TURN_LOG_FUNC(TURN_LOG_LEVEL_INFO, "init user password map end\n");
	
	async_db_init();
}
//xzl--反初始化
void uninit_p2p_server(void)
{
	ur_string_map_free(&p2p_server.p2p_assist_connections);
	ur_string_map_free(&p2p_server.p2p_initiative_connections);
	ur_string_map_free(&p2p_server.p2p_passivity_connections);
	turn_mutex_destroy(&p2p_server.p2p_mutex);

	p2p_report_uninit(); 

	async_db_uninit();
}