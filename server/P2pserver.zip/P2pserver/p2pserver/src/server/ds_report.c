//xzl--此文件为p2p新增，功能是实现了负载均衡汇报客户端。
//负载均衡依据是客户端会话个数
#include <event2/event.h>
#include <pthread.h>
#include "disp_client.h"
#include "tcp_client.h"
#include "gss_protocol.h"
#include "../apps/relay/mainrelay.h"

static pthread_t report_thread = 0;
static struct event_base* report_eb = 0;

#define MAX_DS_COUNT 64
#define DS_SETTING_FILE "/usr/local/etc/p2pds.conf"

void async_db_sql(const char* sql);

//xzl--分派服务器相关设置
typedef struct ds_setting
{
	//本服务器id
	unsigned int server_id;
	//分派服务器个数
	unsigned int ds_count;
	//每个分派服务器的ip地址
	char ds_addr[MAX_DS_COUNT][P2P_SERVER_LEN];
	//每个分派服务器的端口号
	unsigned short port[MAX_DS_COUNT];
	//异步数据库线程个数
	unsigned int async_db_thread_count;
	//负载均衡权重
	double power;
}ds_setting;

//xzl--全局配置
ds_setting g_ds_setting;

//xzl--添加一个分派服务器地址至配置
static int add_ds_server(ds_setting* setting, char* value)
{
	char* port = value;
	while(*port)
	{
		if(*port == ':')
		{
			*port++ = '\0';
			break;
		}
		port++;
	}
	setting->port[setting->ds_count] = atoi(port);
	if(setting->port[setting->ds_count] == 0)
		return 0;
	strcpy(setting->ds_addr[setting->ds_count], value);
	setting->ds_count++;
	return 1;
}

//xzl--读取ini配置文件，包括参数server-id、async_db_thread_count、dispatch-server、power 4个参数
static int read_ds_setting(ds_setting* setting)
{
	char buffer[256];
	FILE *f = fopen(DS_SETTING_FILE, "r");
	if (!f) 
		return 0;

	while( fgets(buffer, sizeof(buffer), f) )
	{
		char seps[] = " =\t";
		char seps1[] = " =\t\r\n";
		char *name,*value;
		name = strtok(buffer, seps);
		if(name)
		{
			value = strtok(0, seps1);
			if(value == 0)
				continue;
		}
		else
		{
			continue;
		}
		if(strcmp(name, "server-id") == 0)
		{
			setting->server_id = atoi(value);
			if(setting->server_id == 0)
			{
				fclose(f);
				return 0;
			}
		}else if(strcmp(name, "async_db_thread_count") == 0)
		{
			setting->async_db_thread_count = atoi(value);
			if(setting->async_db_thread_count == 0)
			{
				fclose(f);
				return 0;
			}
		}
		else if(strcmp(name, "dispatch-server") == 0)
		{
			if(add_ds_server(setting, value) == 0)
			{
				fclose(f);
				return 0;
			}
		}
		else if(strcmp(name, "power") == 0)
		{
			setting->power = atof(value);
		}
	}
	fclose(f);
	return 1;
}

//xzl--重新加载配置文件
static void reload_disp_svr_info(struct disp_svr_info* disp_svr, int* count)
{
	unsigned int i;

	g_ds_setting.ds_count = 0;
	read_ds_setting(&g_ds_setting);

	*count = g_ds_setting.ds_count;
	for(i=0; i<g_ds_setting.ds_count; i++)
	{
		strcpy(disp_svr[i].addr, g_ds_setting.ds_addr[i]);
		disp_svr[i].port = g_ds_setting.port[i];
	}
}

//xzl--往一片内存中写入二进制数据，该内存前面部分是GSS_DATA_HEADER结构体，后面部分是GSS_P2P_DISPATCH_CMD结构体，
//类似这样:
#if 0
	/////////前面部分是GSS_DATA_HEADER结构体/////////////
 	/*data length, data header length is not included*/
	unsigned short len;
	//command
	unsigned char cmd;
	/*if data length more than GSS_MAX_DATA_LEN, long data cut to multiple short data
  	data_seq is sequence number, last is LAST_DATA_SEQ
	*/
	unsigned char data_seq;
	///////////后面部分是GSS_P2P_DISPATCH_CMD结构体/////////////
	unsigned int id;
	char addr[MAX_UID_LEN];
	unsigned int port;
	unsigned int conn_count;
#endif //0
//但是由于内存对齐的问题，在不同的平台或不同的编译器下，同样的结构体的内存排列并不相同;所以最好声明该结构体为__attribute__((packed))
//但是声明packed后内存排列是紧凑的(内存地址不再是4或8的整数)，我们直接操作里面的整形之类的数据在譬如android这样的平台将触发SIGBUS这样的崩溃
//所以这段代码只能在统一的平台使用相同的编译器编译
static void send_disp_info(void* tcp_client)
{
#define DISPATCH_CMD_LEN (sizeof(GSS_DATA_HEADER) + sizeof(GSS_P2P_DISPATCH_CMD))
	char buf[DISPATCH_CMD_LEN];
	GSS_DATA_HEADER* header = (GSS_DATA_HEADER*)buf;
	GSS_P2P_DISPATCH_CMD* disp = (GSS_P2P_DISPATCH_CMD*)(header+1);
	int client_count;

	header->cmd = GSS_P2P_DISPATCH;
	header->data_seq = LAST_DATA_SEQ;
	header->len = htons(sizeof(GSS_P2P_DISPATCH_CMD));

	disp->id = htonl(g_ds_setting.server_id);
	
	if(turn_params.external_ip)
	{
		addr_to_string_no_port(turn_params.external_ip, (u08bits*)disp->addr);
		disp->port = htonl(turn_params.listener_port);
	}
	else
	{
		size_t i;
		for(i=0; i<turn_params.listener.addrs_number; i++)
		{
			strcpy(disp->addr, turn_params.listener.addrs[i]);
			if(strcmp(disp->addr, "127.0.0.1")) //skip 127.0.0.1
				break;
		}
		disp->port = htonl(turn_params.listener_port);
	}

	turn_mutex_lock(&p2p_server.p2p_mutex);
	client_count = g_ds_setting.power * ur_string_map_size(p2p_server.p2p_assist_connections);
	disp->conn_count = htonl(client_count);
	turn_mutex_unlock(&p2p_server.p2p_mutex);

	
	tcp_client_send(tcp_client, buf, DISPATCH_CMD_LEN);
}

//xzl--异步汇报线程
static void* report_thread_func(void *arg)
{
	int result;
	
	UNUSED_ARG(arg);
	
	report_eb = event_base_new();

	result = start_disp_client(report_eb, send_disp_info, reload_disp_svr_info);
	if(result !=0 )		
		return 0;
	
	event_base_dispatch(report_eb);

	stop_disp_client();

	return 0;
}

static void p2p_report_init(void)
{
	pthread_create(&report_thread, 0, report_thread_func, 0);
}

static void p2p_report_uninit(void)
{
	if(report_eb)
		event_base_loopbreak(report_eb);
	if(report_thread)
	{
		pthread_join(report_thread, 0);
		report_thread = 0;
	}
	if(report_eb)
	{
		event_base_free(report_eb);
		report_eb = 0;
	}
}