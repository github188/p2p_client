
//xzl--此文件为p2p新增，完成了异步数据库操作逻辑，也就是tx_session、tx_device两个表的操作
#include "../apps/relay/userdb.h"
#include "../apps/relay/mainrelay.h"

//xzl--sql链表
struct async_sql
{
	char* sql;
	struct async_sql* next;
};

struct async_db
{
	pthread_t* threads;

	pthread_mutex_t mysql_mutex;//multi-thread mysql_real_connect/mysql_init must lock

	pthread_mutex_t sql_mutex;
	pthread_cond_t sql_cond;

	struct async_sql* first_sql;
	struct async_sql* last_sql;

	unsigned char db_thread_run;

	ds_setting setting;
}async_db;

//xzl--此函数是消费者线程函数。目的是消费sql列队并写入数据库
static void* async_db_thread_func(void *arg)
{	
	MYSQL* myconn = 0; //per thread use a mysql connection

	UNUSED_ARG(arg);
	while(async_db.db_thread_run)
	{
		struct async_sql* asql = 0;

		//get sql
		pthread_mutex_lock(&async_db.sql_mutex);
		//xzl--如果sql链表为空，则使用条件变量休眠等待
		if(async_db.first_sql == 0)
			pthread_cond_wait(&async_db.sql_cond, &async_db.sql_mutex);

		//xzl--消费链表头sql
		asql = async_db.first_sql;
		if(asql)
		{
			async_db.first_sql = async_db.first_sql->next;
			if(async_db.first_sql == 0)
				async_db.last_sql = 0;
		}
		//xzl--此时sql已经出列，释放互斥锁
		pthread_mutex_unlock(&async_db.sql_mutex);

		//run sql 
		if(asql)
		{
			while(async_db.db_thread_run)
			{	//xzl--一直尝试获取mysql连接，如果失败，则一秒重试一次,直到获取成功
				//multi-thread mysql_real_connect/mysql_init must lock
				pthread_mutex_lock(&async_db.mysql_mutex);
				myconn = get_mydb_connection(myconn);
				pthread_mutex_unlock(&async_db.mysql_mutex);
				if(myconn)
					break;
				sleep(1);
			}
			//xzl--执行sql语句
			mysql_real_query(myconn, asql->sql, strlen(asql->sql));
			free(asql->sql);
			free(asql);
		}
	}
	return 0;
}

static void sql_log(const char* sql);
//xzl--初始化异步sql。主要是初始化sql链表、互斥锁、条件变量、线程
//xzl--消费线程可以有多条，但是理论上来说只要一条就够了，因为msyql数据库的写入速度才是瓶颈，每秒也就几百条的写入速度
static void async_db_init(void)
{
	unsigned int i=0;

	async_db.first_sql = 0;
	async_db.last_sql = 0;
	async_db.db_thread_run = 0;
	
	pthread_mutex_init(&async_db.mysql_mutex, NULL);
	pthread_mutex_init(&async_db.sql_mutex, NULL);
	pthread_cond_init(&async_db.sql_cond, NULL);

	memset(&async_db.setting, 0, 0);
	if(read_ds_setting(&async_db.setting) == 0)
		return;

	async_db.db_thread_run = 1;
		
	async_db.threads = (pthread_t*)malloc(sizeof(pthread_t) * async_db.setting.async_db_thread_count);
	for(i=0; i<async_db.setting.async_db_thread_count; i++)
		pthread_create(&async_db.threads[i], 0, async_db_thread_func, 0);
		
	//xzl--初始化sql日志	
	sql_log("");
}

static void close_sql_log();

//xzl--反初始化
static void async_db_uninit(void)
{
	unsigned int i=0;
	struct async_sql* asql = 0;

	if(async_db.db_thread_run == 1)
	{
		async_db.db_thread_run = 0;

		pthread_mutex_lock(&async_db.sql_mutex);
		pthread_cond_broadcast(&async_db.sql_cond);
		pthread_mutex_unlock(&async_db.sql_mutex);
		//xzl--等待mysql消费线程退出
		for(i=0; i<async_db.setting.async_db_thread_count; i++)
		{
			pthread_join(async_db.threads[i], 0);
		}
	}

	pthread_cond_destroy(&async_db.sql_cond);
	pthread_mutex_destroy(&async_db.sql_mutex);
	pthread_mutex_destroy(&async_db.mysql_mutex);

	//xzl--释放链表内存
	asql = async_db.first_sql;
	while(asql)
	{
		struct async_sql* next = asql->next;
		free(asql->sql);
		free(asql);
		asql = next;
	}

	free(async_db.threads);

	//xzl--反初始化sql日志
	close_sql_log();
}

//xzl--写sql日志，多个线程频繁的开关日志文件貌似不太可取
//不过考虑到现在服务器改成单线程了，所以也不存在线程安全的问题
/*static void sql_log(const char* sql)
{
	FILE *f = NULL;
	
	f = fopen("/turnsql.txt", "ab");
	if(f)
	{
		fwrite(sql, sizeof(char), strlen(sql), f);
		fwrite("\r\n", sizeof(char), 2, f);
		fclose(f);
	}
}*/


//xzl--优化sql日志写入
static FILE *f = NULL;
static pthread_mutex_t file_mutex;
static int inited = 0;
static void sql_log(const char* sql)
{
	if(!inited){
		inited = 1;
		pthread_mutex_init(&file_mutex, NULL);
		f = fopen("/turnsql.txt", "ab");
		if(f){
			//增大文件缓存
			static char filebuf[1024*64];
			setvbuf(f, filebuf, _IOFBF, sizeof(filebuf));
		}
	}

	if(f && sql)
	{	pthread_mutex_lock(&file_mutex);
		fwrite(sql, sizeof(char), strlen(sql), f);
		fwrite("\r\n", sizeof(char), 2, f);
		pthread_mutex_unlock(&file_mutex);
	}
}
//xzl--关闭全局sql日志
static void close_sql_log(){
	if(inited){
		inited = 0;
		pthread_mutex_lock(&file_mutex);
		if(f){
			fclose(f);
			f = NULL;
		}
		pthread_mutex_unlock(&file_mutex);
		pthread_mutex_destroy(&file_mutex);
	}
}

//cache sql and signal async database thread
void async_db_sql(const char* sql)
{
	//xzl--缓存sql至链表
	struct async_sql* asql;

	if(async_db.db_thread_run == 0)
		return;
	asql = (struct async_sql*)malloc(sizeof(struct async_sql));
	asql->next = 0;
	asql->sql = malloc(strlen(sql)+1);
	strcpy(asql->sql, sql);
	sql_log(sql);
	pthread_mutex_lock(&async_db.sql_mutex);
	if(async_db.last_sql == 0)
	{
		async_db.first_sql = asql;
		async_db.last_sql = asql;
	}
	else
	{
		async_db.last_sql->next = asql;
		async_db.last_sql = asql;
	}
	pthread_cond_signal(&async_db.sql_cond);
	pthread_mutex_unlock(&async_db.sql_mutex);
}

//xzl--客户端下线了
static void async_db_client_shutdown(const char* user)
{
	char sql[256];
	sprintf(sql, "update tx_device set CurServer='', CurServerPort=0, CurServerId=0 WHERE GUID ='%s' and CurServerId=%d",
		user,
		async_db.setting.server_id);
	async_db_sql(sql);
}

//xzl--客户端上线了
static void async_db_client_allocate(const char* user, const char* server)
{
	char sql[256];
	sprintf(sql, 
		"update tx_device set CurServer='%s', CurServerPort=%d, CurServerId=%d WHERE GUID ='%s'", 
		server,
		turn_params.listener_port,
		async_db.setting.server_id,
		user);
	async_db_sql(sql);
}

//xzl--汇报创建了新的连接
static void async_db_report_session_info(const char* remote_user,
	const char* remote_addr,
	const char* local_addr,
	const char* guid,
	int conn_id,
	int type,
	int connect_time,
	int connect_result)
{
	int sec = connect_time / 1000;
	char sql[512];
	if(sec == 0)
		sec = 1;	
	if(remote_user[0] == '\0')
		return;
	sprintf(sql, 
		"insert into tx_session (DevGuid,DevIP,ClientIP,ClientGuid,ClientSessionID,Type,BeginTime,EndTime,Success)"
		" values ('%s','%s','%s','%s',%d,%d, date_sub(now(),interval %d second),now(),%d)",
		remote_user,
		remote_addr,
		local_addr,
		guid,
		conn_id,
		type,
		sec,
		connect_result);
	async_db_sql(sql);
}

//xzl--连接已经关断
static void async_db_report_session_destroy(const char* guid, int conn_id)
{
	char sql[256];
	if(guid[0] == '\0')
		return;
	sprintf(sql, "update tx_session set SessionEndTime = now() where ClientGuid='%s' and ClientSessionID=%d", 
		guid,
		conn_id);
	async_db_sql(sql);
}
