//xzl--add file by p2p
//定义了分派服务器相关的命令结构体
//还有SDK于服务器间的一些特定约定

#ifndef __DS_PROTOCOL_H__
#define __DS_PROTOCOL_H__

#define P2P_CLIENT_PASSWORD "p2ppassword"
#define P2P_CLIENT_PREFIX "p2pc____"

#define P2P_DISPATCH_REQUEST 1
#define P2P_DISPATCH_RESPONSE 2
#define P2P_QUERY_REQUEST 3
#define P2P_QUERY_RESPONSE 4
#define P2P_REPORT_SVR_INFO 5
#define P2P_REPORT_SVR_INFO_RESPONSE 6

#define P2P_USER_MAX_LEN 128
#define P2P_PASSWORD_MAX_LEN 64
#define P2P_SERVER_LEN 64

#define P2P_DS_VERSION_1 1
#define P2P_DS_VERSION_2 2

#define P2P_HEADER_MAGIC 0xACDF

#define P2P_SERVER_REPORT_TIME 5 //second

#define MAX_IP_COUNT_PRE_SERVER 4

#pragma pack(1)

/**
 * This structure data header. All the fields are in network byte
 * order when it's on the wire.
 */
typedef struct p2p_ds_header 
{
	unsigned char version;
	unsigned short length; //head length and data length
	unsigned char cmd;
	unsigned short magic; //the magic must is P2P_HEADER_MAGIC
	unsigned short reserve; //reserved, now is zero
}p2p_ds_header;

typedef struct p2p_ds_user 
{
	char user[P2P_USER_MAX_LEN];
	char password[P2P_PASSWORD_MAX_LEN];
}p2p_ds_user;

typedef struct p2p_ds_query 
{
	char dest_user[P2P_USER_MAX_LEN];
}p2p_ds_query;

typedef struct p2p_dispatch_response 
{
	int result;
	char server[P2P_SERVER_LEN];
	unsigned short port;
	unsigned int server_id;
}p2p_dispatch_response;

typedef struct p2p_svr_info_report
{
	unsigned int server_id;
	unsigned int addr_count;
	char server_addr[MAX_IP_COUNT_PRE_SERVER][P2P_SERVER_LEN];
	unsigned short port[MAX_IP_COUNT_PRE_SERVER];
	unsigned int client_count;
	int avg_transmit_count;
}p2p_svr_info_report;

#pragma pack()

#endif